package com.example.material;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;


public class SecondFragment extends Fragment {

    Button DatePicker;
    TextView Name;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_second, container, false);
        Name=view.findViewById(R.id.name2);
        Profile p = new Profile();
        Name.setText(p.name);

        TextInputEditText tectinput = view.findViewById(R.id.goa);
        tectinput.setFocusable(false);

        DatePicker = view.findViewById(R.id.datebtn);
        final MaterialTextView dateview = (MaterialTextView) view.findViewById(R.id.birthtxt);

        MaterialDatePicker.Builder builder = MaterialDatePicker.Builder.datePicker();

        final MaterialDatePicker materialDatePicker = builder.build();

        DatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDatePicker.show(getFragmentManager(), "Date_Picker");

            }
        });

        materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
            @Override
            public void onPositiveButtonClick(Object selection) {
                dateview.setText(materialDatePicker.getHeaderText());

            }
        });

    return view;
    }
}