package com.example.material;

public class Profile {
     String name = "Shivanand";
     String email = "shivananben@gmail.com";
     String phone = "9764209126";
     String password = "password";

}
